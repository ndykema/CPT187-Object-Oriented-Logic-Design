package edu.cpt187.lastname.program5;
import java.util.*;
import java.io.*;
public class MainClass {
	public static final String FILE_PATH = "ToolFile.txt";

	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
char menuSelection;
char subSelection;
Tool heldTool;
//Send the File path over to the Tool Keeper Method to load the file into the arrayList
ToolKeeper.loadToolList(FILE_PATH);

//Get a valid menu selection
menuSelection = getValidMenuSelection(input);

//Using the menu selection the program determines what to display and what methods to call
		while(menuSelection!='Q')
		{
			if (menuSelection == 'A')
			{	
				//I use the holdTool variable to more easily pull the information that I want based on the tool that the 
				//user searches for. This way all the information from this point forward is related on the tool the user
				//ask for.
				heldTool = searchTool(input);
				displaySingleTool(heldTool);
				//Display the tool, then this if statement determines if the tool comes back as null (if the tool doesn't exist)
				if (heldTool != null) 
				{
					//If the tool exists, the sub menu is displayed
					subSelection = getValidSubSelection(input);
					if(subSelection =='A') 
					{
					//User selection to remove the searched tool
						removeTool(input,heldTool);
					}
					else if(subSelection =='B') 
					{
					//Selection that will "check the tool" out of the Tool List inventory
					//Calls to change the tool availability variable from true to false and displays confirmation message
						checkToolOut(input,heldTool);
					}
					else if(subSelection =='C')
					{
					//Selection that will "return" the tool to the Tool List inventory
					//Calls to change the tool availability variable from false to true
						checkToolIn(input,heldTool);
					}	
				}
			}
			else if (menuSelection =='B')
			{
			//Calls the method to display the Tool List Array in a organized clean manner
				displayToolList();
			}
			else if (menuSelection =='C')
			{
			//Calls to add a tool to the Array List, prompts the user for the tool name and owner
				addTool(input);
			}
			else if (menuSelection =='D')
			{
			//Prints the current Array List to the File
				printToFile();
			}
			
			menuSelection = getValidMenuSelection(input);
		}
//Confirmation Message that the Program finished
System.out.println("\t***The Tool Keeper Program Has Successfully Quit***");
printToFile();
	
	}
	//Method to display the menu
	public static void displayMenu()
	{
		System.out.println("-------------------------------------------------------------------------");
		System.out.println("\n\n\t   ***Welcome to the Tool Keeper Program***");
		System.out.println("\n\tPlease Select an option from the Menu Below\n");
		System.out.println("\t\tA.) Locate Tool");
		System.out.println("\t\tB.) Display List of Tools");
		System.out.println("\t\tC.) Add a Tool to the Tool List");
		System.out.println("\t\tD.) Back-Up Tool List File");
		System.out.println("\t\tQ.) Quit Program\n");
	}
	//Method to display the subMenu
	public static void displaySubMenu()
	{
		System.out.println("\t\tA.) Remove Tool from the Tool List");
		System.out.println("\t\tB.) Check out Tool from Inventory");
		System.out.println("\t\tC.) Return Tool to Inventory");
		System.out.println("\t\tD.) Cancel");
	}
	//Method to get a valid Menu selection from the user
	public static char getValidMenuSelection(Scanner borrowedInput)
	{
		char selection;
		displayMenu();
		selection = borrowedInput.next().toUpperCase().charAt(0);
		while (selection != 'A' && selection != 'B' && selection != 'Q'&& selection != 'C'&& selection != 'D') {
			System.out.println("\t  Please enter a valid selection!\n\t\t Example input: A");
			selection = borrowedInput.next().toUpperCase().charAt(0);
		}
		return selection;
	}
	//Method to get a valid Sub Menu selection from the user
	public static char getValidSubSelection(Scanner borrowedInput)

	{
		char selection;
		displaySubMenu();
		selection = borrowedInput.next().toUpperCase().charAt(0);
		while (selection != 'A' && selection != 'B' && selection != 'C'&& selection != 'D') {
			System.out.println("\t  Please enter a valid selection!\n\t\t Example input: A");
			selection = borrowedInput.next().toUpperCase().charAt(0);
		}
		return selection;
	}
	//Method to add a tool to the Tool List
	public static void addTool(Scanner borrowedInput)
	{
		String toolId;
		String toolOwner;
		//Prompt the User to enter a Tool name
		System.out.println("\tPlease enter the name of the tool you wish to add to the Tool List!");
		toolId = borrowedInput.next().toLowerCase();
		//Prompt the user to enter the owner of the tool
		System.out.println("\tPlease enter the owner of the tool! Example:Chad");
		toolOwner = borrowedInput.next();
		//Create the tool object
		Tool customTool = new Tool(toolId, toolOwner);
		//Use the ToolKeeper sortToolList Method to find the location that the tool would sit based on alphabetically searching
		//The .add method is called in the Sort Method.
		ToolKeeper.sortToolList(toolId, customTool);
		System.out.printf("\t\t***You added %s to the Tool List!***\n", toolId.toUpperCase());
	}
	//Method to search for a tool
	public static Tool searchTool(Scanner borrowedInput) 
	{ 	
		String searchedTool;
		Tool tool;
		System.out.println("\tPlease enter the name of the tool!");
		System.out.println("\tNOTE: If there are spaces in your tool name, use a hypen instead!!");
		System.out.println("\t------------------------------------------------------------------\n\n");
		//get the tool name that the user wants to search for
		searchedTool = borrowedInput.next().toLowerCase();
		// send it to the toolKeeper method to search by the tool name
		tool = ToolKeeper.findToolByName(searchedTool);
		return tool;
		
	}
	//Method to remove a tool from the Array List
	public static void removeTool(Scanner borrowedInput,Tool toolInput) 
	{ 	Tool discardedTool;
		String toolName;
		toolName = toolInput.getToolName();
		discardedTool = ToolKeeper.findToolByName(toolName);
		if (discardedTool == null) {
			System.out.println("***You cannot remove a item that doesn't exist in the Tool List***\n");
		}
		else {	
		ToolKeeper.removeTool(discardedTool);
		System.out.printf("\t***You removed %s from the Tool List***\n",toolName.toUpperCase());
		}
	}
	//Method to display the tool list
	public static void displayToolList()
	{
		//Load in the Array list and then use a for loop to print the components out neatly
		 ArrayList<Tool> nameList = ToolKeeper.getToolList();
		for (int i = 0; i<nameList.size();i++) {
			System.out.printf("%-25s",nameList.get(i).getToolName());
			System.out.printf("%-10s",nameList.get(i).getToolAvailability());
			System.out.printf("%-10s\n",nameList.get(i).getOwnerName());
		}
		System.out.println("\n");
	}
	//Method to display a single tool for the user
	public static void displaySingleTool(Tool toolInput)
	{
		//if the tool is null, the program needs a way to tell the user it doesn't exist
		if (toolInput == null) 
		{
			System.out.println("\tThe tool you are looking for does not exist in the Tool List!\n\n");
		}
		//If the tool does exist, we show the name, owner, and availability
		else {
		System.out.print("\n\tTool: "+toolInput.getToolName()+" ");
		System.out.println("	Tool Owner: "+toolInput.getOwnerName()+"\n");
		System.out.printf("\tYour Tool: %s exists in the Tool List Inventory!\n\n",toolInput.getToolName().toUpperCase());
		//Based on the boolean value next to the tool, a more friendly way to tell the user true or false - is to tell them whether it is 
		//in inventory stock or not
		if (toolInput.getToolAvailability()==false) {
			System.out.println("\tInventory Status: Checked Out of Inventory.\n\n");
		}
		else {
			System.out.println("\tInventory Status: Available for Check Out.\n\n");
		}
		}
		
	}
	//Method to print the current Array List to a file
	public static void printToFile() throws IOException
	{
		ArrayList<Tool> nameList = ToolKeeper.getToolList();
	
		PrintWriter outputFile = new PrintWriter(FILE_PATH);
		for (int i = 0; i<nameList.size();i++) {
			outputFile.println(nameList.get(i).getToolName()+
					" "+ nameList.get(i).getToolAvailability()+
					" "+nameList.get(i).getOwnerName());
			
		}
		outputFile.close();
		System.out.println("A Tool List Back-Up has been properly performed.");
		
	}
	//Method to change the availability of the tool (checking it out of inventory)
	public static void checkToolOut(Scanner borrowedInput, Tool toolInput) 
	{
		
		boolean availability = false;
		//If the tool doesn't exist, show that it doesn't
		if(toolInput == null) {
			System.out.println("\tPlease try another tool.");
		}
		//If it does, then prompt the user about it's availability 
		else {
			//If the tool is already "not in inventory" tell the user
			if (toolInput.getToolAvailability()==false) {
				System.out.println("\tThis tool is unable to be checked out as it is NOT currently in inventory");
				System.out.println("\t--------------------------------------------------------------------------\n");
			}
			//A confirmation message is given as the boolean is changed
			else if (toolInput.getToolAvailability()==true) {
				toolInput.setToolAvailability(availability);
				System.out.printf("\t***You have checked out %s from the Tool List***\n",toolInput.getToolName());
				System.out.println("-------------------------------------------------------------------------\n");
		}
		}
	}
	//Method to check the tool back into the Array List
	public static void checkToolIn(Scanner borrowedInput, Tool toolInput)
	{
		{
			
			boolean availability = true;
			//If the tool doesn't exist, prompt the user
			if(toolInput == null) {
				System.out.println("\tPlease try another tool.");
			}
			//If the Tool is checked out, the boolean changes to put it back
			else {
				if (toolInput.getToolAvailability()==false) {
					toolInput.setToolAvailability(availability);
					System.out.printf("\t***You returned %s into the Tool List inventory***",toolInput.getToolName());
					System.out.println("\n\tThe availability of the tool has been updated appropriately!");
					System.out.println("------------------------------------------------------------------------------------------\n");
				}
				//If the tool is already in Inventory, the user is prompted that they can't return a tool that is already there
				else if (toolInput.getToolAvailability()==true) {
					System.out.println("\tYou are unable to check in a tool that is already located in Inventory.");
					System.out.println("\t----------------------------------------------------------------------\n");
			}
			}
		}
	}
	}

		
					
	


	
