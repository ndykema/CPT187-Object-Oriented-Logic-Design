package edu.cpt187.dykema.program6;

public class Computer {
	
		private String name;
		private String model;
		private String description;
		private double price;

		public Computer(String name, String model, String description, double price) {
			this.name = name;
			this.model = model;
			this.description = description;
			this.price = price;
		}
		
		public Computer(Computer origComp) {
			this.name = origComp.name;
			this.model = origComp.model;
			this.description = origComp.description;
			this.price = origComp.price;
		}
		
		public double getPrice() {
			return price;
		}

		public void setPrice(double price) {
			this.price = price;
		}

		public String getName() {
			return name;
		}

		public String getModel() {
			return model;
		}

		public String getDescription() {
			return description;
		}
		
	}

